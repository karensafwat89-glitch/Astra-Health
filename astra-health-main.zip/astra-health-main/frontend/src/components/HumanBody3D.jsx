
export default function HumanBody3D() {
  return (
    <section
      style={{
        width: "100%",
        padding: "20px",
        borderRadius: "16px",
        background: "#111827",
        color: "#ffffff",
        boxSizing: "border-box",
      }}
    >
      <h2 style={{ marginTop: 0, marginBottom: "8px" }}>
        3D Skeletal System
      </h2>

      <p style={{ color: "#cbd5e1", marginTop: 0 }}>
        Interactive 3D human skeleton visualization
      </p>

      <div
        style={{
          width: "100%",
          height: "600px",
          overflow: "hidden",
          borderRadius: "12px",
          background: "#000000",
        }}
      >
        <iframe
          title="Male Skeleton - Sketchfab 3D Model"
          src="https://sketchfab.com/models/7ae059d4a29844e78fd2f97978bd886a/embed"
          width="100%"
          height="100%"
          frameBorder="0"
          allow="autoplay; fullscreen; xr-spatial-tracking"
          allowFullScreen
          loading="lazy"
          style={{ border: "none" }}
        />
      </div>

      <p style={{ fontSize: "12px", color: "#9ca3af", marginBottom: 0 }}>
        3D model:{" "}
        <a
          href="https://sketchfab.com/3d-models/male-skeleton-7ae059d4a29844e78fd2f97978bd886a"
          target="_blank"
          rel="noreferrer"
          style={{ color: "#38bdf8" }}
        >
          Male Skeleton by LeoVitalis on Sketchfab
        </a>
      </p>
    </section>
  );
}
